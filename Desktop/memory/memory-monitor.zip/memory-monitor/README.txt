#!/bin/bash

# =============================================================================
# SYSTEM MONITOR - Tizim resurslarini kuzatish va Telegram orqali xabar yuborish
# Muallif: Manus AI
# Versiya: 1.0
# =============================================================================

echo "System Monitor - Tizim resurslarini kuzatish va Telegram orqali xabar yuborish"
echo "Versiya: 1.0"
echo ""
echo "Bu dastur serveringizning RAM, CPU va disk resurslarini kuzatib boradi"
echo "va belgilangan chegaradan oshganda Telegram orqali xabar yuboradi."
echo ""
echo "O'rnatish uchun quyidagi buyruqni bajaring:"
echo "  sudo ./install.sh"
echo ""
echo "Batafsil ma'lumot uchun README.md faylini o'qing."
