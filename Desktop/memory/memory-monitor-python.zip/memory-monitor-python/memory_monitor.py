#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SYSTEM MONITOR - Tizim resurslarini kuzatish va Telegram orqali xabar yuborish
Versiya: 1.0.0
Python versiyasi
"""

import os
import sys
import time
import logging
import argparse
import configparser
import subprocess
import platform
import socket
import json
import requests
from datetime import datetime
import psutil

# Default configuration values
DEFAULT_CONFIG_FILE = "/etc/memory-monitor/config.conf"
DEFAULT_LOG_FILE = "/var/log/memory_monitor.log"
DEFAULT_THRESHOLD = 80
DEFAULT_INTERVAL = 60
DEFAULT_LOG_LEVEL = "INFO"

class SystemMonitor:
    def __init__(self, config_file=DEFAULT_CONFIG_FILE):
        """Initialize the SystemMonitor with the given configuration file."""
        self.config_file = config_file
        self.config = self._load_config()
        self._setup_logging()
        self.last_alert_times = {
            'ram': 0,
            'cpu': 0,
            'disk': 0,
            'swap': 0,
            'load': 0,
            'network': 0
        }
        self.logger.info(f"Memory monitoring service boshlandi")
        self.logger.info(f"Konfiguratsiya fayli: {self.config_file}")
        self.logger.debug(f"Monitoring sozlamalari: RAM {self.config['threshold']}%, interval {self.config['check_interval']} sek")
        
        # Test Telegram connection at startup
        self.test_telegram_connection()

    def _load_config(self):
        """Load configuration from file or use defaults."""
        config = {
            'bot_token': "",
            'chat_id': "",
            'log_file': DEFAULT_LOG_FILE,
            'threshold': DEFAULT_THRESHOLD,
            'check_interval': DEFAULT_INTERVAL,
            'log_level': DEFAULT_LOG_LEVEL,
            'alert_message_title': "🛑 SYSTEM MONITOR ALERT",
            'include_top_processes': True,
            'top_processes_count': 10,
            'monitor_cpu': True,
            'cpu_threshold': 90,
            'monitor_disk': True,
            'disk_threshold': 90,
            'disk_path': "/",
            'monitor_swap': True,
            'swap_threshold': 80,
            'monitor_load': True,
            'load_threshold': 5,
            'monitor_network': True,
            'network_interface': "",
            'network_threshold': 90,
            # Database integration settings
            'db_enabled': False,
            'db_type': "sqlite",  # sqlite, mysql, postgresql
            'db_host': "localhost",
            'db_port': 3306,
            'db_name': "system_monitor",
            'db_user': "",
            'db_password': "",
            # Prometheus integration settings
            'prometheus_enabled': False,
            'prometheus_port': 9090
        }
        
        if not os.path.exists(self.config_file):
            print(f"XATO: Konfiguratsiya fayli topilmadi: {self.config_file}")
            print("Standart konfiguratsiya qiymatlari ishlatiladi.")
            return config
        
        try:
            # Read configuration file
            parser = configparser.ConfigParser()
            parser.read(self.config_file)
            
            # General settings
            if 'General' in parser:
                for key in ['bot_token', 'chat_id', 'log_file', 'log_level', 'alert_message_title']:
                    if key in parser['General']:
                        config[key] = parser['General'][key]
                
                for key in ['threshold', 'check_interval', 'top_processes_count']:
                    if key in parser['General']:
                        config[key] = parser['General'].getint(key)
                
                if 'include_top_processes' in parser['General']:
                    config['include_top_processes'] = parser['General'].getboolean('include_top_processes')
            
            # CPU monitoring
            if 'CPU' in parser:
                if 'monitor_cpu' in parser['CPU']:
                    config['monitor_cpu'] = parser['CPU'].getboolean('monitor_cpu')
                if 'cpu_threshold' in parser['CPU']:
                    config['cpu_threshold'] = parser['CPU'].getint('cpu_threshold')
            
            # Disk monitoring
            if 'Disk' in parser:
                if 'monitor_disk' in parser['Disk']:
                    config['monitor_disk'] = parser['Disk'].getboolean('monitor_disk')
                if 'disk_threshold' in parser['Disk']:
                    config['disk_threshold'] = parser['Disk'].getint('disk_threshold')
                if 'disk_path' in parser['Disk']:
                    config['disk_path'] = parser['Disk']['disk_path']
            
            # Swap monitoring
            if 'Swap' in parser:
                if 'monitor_swap' in parser['Swap']:
                    config['monitor_swap'] = parser['Swap'].getboolean('monitor_swap')
                if 'swap_threshold' in parser['Swap']:
                    config['swap_threshold'] = parser['Swap'].getint('swap_threshold')
            
            # Load monitoring
            if 'Load' in parser:
                if 'monitor_load' in parser['Load']:
                    config['monitor_load'] = parser['Load'].getboolean('monitor_load')
                if 'load_threshold' in parser['Load']:
                    config['load_threshold'] = parser['Load'].getint('load_threshold')
            
            # Network monitoring
            if 'Network' in parser:
                if 'monitor_network' in parser['Network']:
                    config['monitor_network'] = parser['Network'].getboolean('monitor_network')
                if 'network_interface' in parser['Network']:
                    config['network_interface'] = parser['Network']['network_interface']
                if 'network_threshold' in parser['Network']:
                    config['network_threshold'] = parser['Network'].getint('network_threshold')
            
            # Database integration
            if 'Database' in parser:
                if 'db_enabled' in parser['Database']:
                    config['db_enabled'] = parser['Database'].getboolean('db_enabled')
                for key in ['db_type', 'db_host', 'db_name', 'db_user', 'db_password']:
                    if key in parser['Database']:
                        config[key] = parser['Database'][key]
                if 'db_port' in parser['Database']:
                    config['db_port'] = parser['Database'].getint('db_port')
            
            # Prometheus integration
            if 'Prometheus' in parser:
                if 'prometheus_enabled' in parser['Prometheus']:
                    config['prometheus_enabled'] = parser['Prometheus'].getboolean('prometheus_enabled')
                if 'prometheus_port' in parser['Prometheus']:
                    config['prometheus_port'] = parser['Prometheus'].getint('prometheus_port')
            
        except Exception as e:
            print(f"Konfiguratsiya faylini o'qishda xatolik: {e}")
            print("Standart konfiguratsiya qiymatlari ishlatiladi.")
        
        # Validate required settings
        if not config['bot_token'] or not config['chat_id']:
            print("XATO: BOT_TOKEN va CHAT_ID konfiguratsiya faylida ko'rsatilishi kerak.")
            sys.exit(1)
        
        # Set default network interface if not specified
        if not config['network_interface']:
            interfaces = psutil.net_if_addrs()
            for interface in interfaces:
                if interface != 'lo':  # Skip loopback
                    config['network_interface'] = interface
                    break
        
        return config

    def _setup_logging(self):
        """Set up logging configuration."""
        log_levels = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR
        }
        
        log_level = log_levels.get(self.config['log_level'], logging.INFO)
        
        # Create log directory if it doesn't exist
        log_dir = os.path.dirname(self.config['log_file'])
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        # Configure logging
        logging.basicConfig(
            filename=self.config['log_file'],
            level=log_level,
            format='%(asctime)s - [%(levelname)s] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Add console handler for DEBUG and ERROR levels
        console = logging.StreamHandler()
        console.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s')
        console.setFormatter(formatter)
        
        # Add the handler to the root logger
        self.logger = logging.getLogger('')
        self.logger.addHandler(console)

    def get_system_info(self):
        """Get system information."""
        hostname = socket.gethostname()
        try:
            server_ip = socket.gethostbyname(socket.gethostname())
        except:
            server_ip = "127.0.0.1"
        
        # Get more detailed IP if available
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            server_ip = s.getsockname()[0]
            s.close()
        except:
            pass
        
        kernel = platform.release()
        os_info = platform.platform()
        
        # Get uptime
        uptime = ""
        try:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = float(f.readline().split()[0])
                uptime_days = int(uptime_seconds / 86400)
                uptime_hours = int((uptime_seconds % 86400) / 3600)
                uptime_minutes = int((uptime_seconds % 3600) / 60)
                uptime = f"up {uptime_days} days, {uptime_hours} hours, {uptime_minutes} minutes"
        except:
            uptime = "unknown"
        
        # Get CPU info
        cpu_info = platform.processor()
        cpu_cores = psutil.cpu_count(logical=True)
        
        # Get memory info
        mem = psutil.virtual_memory()
        total_memory = f"{mem.total / (1024**3):.1f}G"
        
        # Get disk info
        disk = psutil.disk_usage(self.config['disk_path'])
        total_disk = f"{disk.total / (1024**3):.1f}G"
        
        return {
            "hostname": hostname,
            "ip": server_ip,
            "os": os_info,
            "kernel": kernel,
            "cpu": f"{cpu_info} ({cpu_cores} cores)",
            "uptime": uptime,
            "total_ram": total_memory,
            "total_disk": f"{total_disk} ({self.config['disk_path']})"
        }

    def check_ram_usage(self):
        """Check RAM usage and return usage percentage."""
        mem = psutil.virtual_memory()
        usage_percent = mem.percent
        return usage_percent

    def check_cpu_usage(self):
        """Check CPU usage and return usage percentage."""
        if not self.config['monitor_cpu']:
            return 0
        
        cpu_percent = psutil.cpu_percent(interval=1)
        return cpu_percent

    def check_disk_usage(self):
        """Check disk usage and return usage percentage."""
        if not self.config['monitor_disk']:
            return 0
        
        disk = psutil.disk_usage(self.config['disk_path'])
        return disk.percent

    def check_swap_usage(self):
        """Check swap usage and return usage percentage."""
        if not self.config['monitor_swap']:
            return 0
        
        swap = psutil.swap_memory()
        if swap.total == 0:
            return 0
        
        return swap.percent

    def check_load_average(self):
        """Check load average and return load per core."""
        if not self.config['monitor_load']:
            return 0
        
        cpu_cores = psutil.cpu_count(logical=True)
        load_avg = os.getloadavg()[0]  # 1 minute load average
        load_per_core = load_avg / cpu_cores
        
        return load_per_core * 100  # Convert to percentage for threshold comparison

    def check_network_usage(self):
        """Check network usage and return usage in Mbps."""
        if not self.config['monitor_network']:
            return 0, 0
        
        interface = self.config['network_interface']
        
        # Check if interface exists
        if interface not in psutil.net_if_addrs():
            self.logger.warning(f"Network interfeysi topilmadi: {interface}")
            return 0, 0
        
        # Get initial counters
        net_io_counters_1 = psutil.net_io_counters(pernic=True)
        if interface not in net_io_counters_1:
            self.logger.warning(f"Network interfeysi statistikasi topilmadi: {interface}")
            return 0, 0
        
        rx_bytes_1 = net_io_counters_1[interface].bytes_recv
        tx_bytes_1 = net_io_counters_1[interface].bytes_sent
        
        # Wait 1 second
        time.sleep(1)
        
        # Get counters again
        net_io_counters_2 = psutil.net_io_counters(pernic=True)
        rx_bytes_2 = net_io_counters_2[interface].bytes_recv
        tx_bytes_2 = net_io_counters_2[interface].bytes_sent
        
        # Calculate rates in Mbps
        rx_rate = (rx_bytes_2 - rx_bytes_1) * 8 / 1024 / 1024  # Convert to Mbps
        tx_rate = (tx_bytes_2 - tx_bytes_1) * 8 / 1024 / 1024  # Convert to Mbps
        
        return rx_rate, tx_rate

    def get_top_processes(self, resource_type):
        """Get top processes based on resource type."""
        count = self.config['top_processes_count']
        
        if resource_type == "RAM":
            processes = []
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'memory_percent', 'cpu_percent']):
                try:
                    processes.append({
                        'pid': proc.info['pid'],
                        'ppid': proc.info['ppid'],
                        'name': proc.info['name'],
                        'memory_percent': proc.info['memory_percent'],
                        'cpu_percent': proc.info['cpu_percent']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
            
            # Sort by memory usage
            processes.sort(key=lambda x: x['memory_percent'], reverse=True)
            
            # Format output
            result = "PID PPID COMMAND %MEM% %CPU%\n"
            for proc in processes[:count]:
                result += f"{proc['pid']} {proc['ppid']} {proc['name']} {proc['memory_percent']:.1f}% {proc['cpu_percent']:.1f}%\n"
            
            return result
        
        elif resource_type == "CPU":
            processes = []
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    processes.append({
                        'pid': proc.info['pid'],
                        'ppid': proc.info['ppid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
            
            # Sort by CPU usage
            processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
            
            # Format output
            result = "PID PPID COMMAND %CPU% %MEM%\n"
            for proc in processes[:count]:
                result += f"{proc['pid']} {proc['ppid']} {proc['name']} {proc['cpu_percent']:.1f}% {proc['memory_percent']:.1f}%\n"
            
            return result
        
        elif resource_type == "Disk":
            try:
                # Use subprocess to get disk usage by directory
                output = subprocess.check_output(
                    f"du -h {self.config['disk_path']}/* 2>/dev/null | sort -rh | head -n {count}",
                    shell=True, text=True
                )
                return output
            except subprocess.SubprocessError:
                return "Could not get disk usage information"
        
        elif resource_type == "Swap":
            processes = []
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'memory_percent']):
                try:
                    processes.append({
                        'pid': proc.info['pid'],
                        'ppid': proc.info['ppid'],
                        'name': proc.info['name'],
                        'memory_percent': proc.info['memory_percent']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
            
            # Sort by memory usage (as a proxy for swap usage)
            processes.sort(key=lambda x: x['memory_percent'], reverse=True)
            
            # Format output
            result = "PID PPID COMMAND %MEM%\n"
            for proc in processes[:count]:
                result += f"{proc['pid']} {proc['ppid']} {proc['name']} {proc['memory_percent']:.1f}%\n"
            
            return result
        
        elif resource_type == "Load":
            processes = []
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'cpu_percent']):
                try:
                    processes.append({
                        'pid': proc.info['pid'],
                        'ppid': proc.info['ppid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
            
            # Sort by CPU usage
            processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
            
            # Format output
            result = "PID PPID COMMAND %CPU%\n"
            for proc in processes[:count]:
                result += f"{proc['pid']} {proc['ppid']} {proc['name']} {proc['cpu_percent']:.1f}%\n"
            
            return result
        
        elif resource_type == "Network":
            try:
                # Use subprocess to get network connections
                output = subprocess.check_output(
                    f"netstat -tunapl 2>/dev/null | grep -v '127.0.0.1' | awk '{{print $5,$6,$7}}' | sort | uniq -c | sort -nr | head -n {count}",
                    shell=True, text=True
                )
                return output
            except subprocess.SubprocessError:
                return "Could not get network connection information"
        
        return "Unknown resource type"

    def send_telegram_alert(self, alert_type, usage_value):
        """Send alert via Telegram."""
        current_time = int(time.time())
        alert_interval = self.config['check_interval'] * 10  # Minimum time between alerts
        
        # Check if we should send an alert (rate limiting)
        alert_key = alert_type.lower()
        if alert_key not in self.last_alert_times:
            self.last_alert_times[alert_key] = 0
        
        time_since_last_alert = current_time - self.last_alert_times[alert_key]
        if time_since_last_alert < alert_interval:
            self.logger.debug(f"{alert_type} alert cheklandi (so'nggi xabardan {time_since_last_alert} soniya o'tdi)")
            return False
        
        # Prepare message
        date_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        system_info = self.get_system_info()
        
        message = f"{self.config['alert_message_title']} - *{alert_type}*\n"
        message += f"📅 Sana: {date_str}\n"
        message += f"🖥️ Hostname: `{system_info['hostname']}`\n"
        message += f"🌐 Server IP: `{system_info['ip']}`\n"
        message += f"💥 {alert_type} foydalanish: *{usage_value}*\n"
        
        # Add top processes if enabled
        if self.config['include_top_processes']:
            top_processes = self.get_top_processes(alert_type)
            message += f"\n🔍 Top jarayonlar:\n```\n{top_processes}```\n"
        
        # Add system info
        sys_info_str = "\n".join([f"{k}: {v}" for k, v in system_info.items()])
        message += f"\n📊 Tizim ma'lumotlari:\n```\n{sys_info_str}```"
        
        # Log the message
        self.logger.info("-" * 40)
        self.logger.info(message)
        
        # Send to Telegram with retry
        max_retries = 3
        retry = 0
        success = False
        
        while retry < max_retries and not success:
            try:
                self.logger.debug(f"Telegramga xabar yuborilmoqda: {alert_type}")
                
                # Send message
                url = f"https://api.telegram.org/bot{self.config['bot_token']}/sendMessage"
                payload = {
                    'chat_id': self.config['chat_id'],
                    'text': message,
                    'parse_mode': 'Markdown'
                }
                
                response = requests.post(url, data=payload, timeout=30)
                response_json = response.json()
                
                if response_json.get('ok'):
                    self.logger.info(f"{alert_type} alert xabari Telegramga muvaffaqiyatli yuborildi")
                    success = True
                    self.last_alert_times[alert_key] = current_time
                else:
                    retry += 1
                    error_description = response_json.get('description', 'Unknown error')
                    self.logger.warning(f"Telegramga xabar yuborishda xatolik ({retry}/{max_retries}): {error_description}")
                    time.sleep(2)  # Wait before retrying
            
            except Exception as e:
                retry += 1
                self.logger.warning(f"Telegramga xabar yuborishda xatolik ({retry}/{max_retries}): {str(e)}")
                time.sleep(2)  # Wait before retrying
        
        # If all retries failed
        if not success:
            self.logger.error(f"Telegramga xabar yuborib bo'lmadi ({max_retries} urinishdan so'ng)")
            self.logger.error(f"BOT_TOKEN: {self.config['bot_token'][:5]}...{self.config['bot_token'][-5:]}")
            self.logger.error(f"CHAT_ID: {self.config['chat_id']}")
            return False
        
        return True

    def test_telegram_connection(self):
        """Test Telegram connection at startup."""
        self.logger.info("Telegram bog'lanishini tekshirish...")
        
        system_info = self.get_system_info()
        date_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        test_message = f"🔄 System Monitor xizmati ishga tushirildi.\n"
        test_message += f"🖥️ Hostname: `{system_info['hostname']}`\n"
        test_message += f"🌐 Server IP: `{system_info['ip']}`\n"
        test_message += f"⏱️ Vaqt: {date_str}"
        
        try:
            url = f"https://api.telegram.org/bot{self.config['bot_token']}/sendMessage"
            payload = {
                'chat_id': self.config['chat_id'],
                'text': test_message,
                'parse_mode': 'Markdown'
            }
            
            response = requests.post(url, data=payload, timeout=10)
            response_json = response.json()
            
            if response_json.get('ok'):
                self.logger.info("Telegram bog'lanishi muvaffaqiyatli tekshirildi")
                return True
            else:
                error_description = response_json.get('description', 'Unknown error')
                self.logger.error(f"Telegram bog'lanishini tekshirishda xatolik: {error_description}")
                self.logger.error(f"BOT_TOKEN: {self.config['bot_token'][:5]}...{self.config['bot_token'][-5:]}")
                self.logger.error(f"CHAT_ID: {self.config['chat_id']}")
                return False
                
        except Exception as e:
            self.logger.error(f"Telegram bog'lanishini tekshirishda xatolik: {str(e)}")
            return False

    def store_metrics_in_database(self, metrics):
        """Store metrics in database if enabled."""
        if not self.config['db_enabled']:
            return
        
        try:
            # This is a placeholder for database integration
            # In a real implementation, you would connect to the database and store the metrics
            self.logger.debug(f"Ma'lumotlar bazasiga metrikalar saqlandi: {metrics}")
            
            # Example implementation for different database types would go here
            db_type = self.config['db_type']
            
            if db_type == 'sqlite':
                # SQLite implementation
                pass
            elif db_type == 'mysql':
                # MySQL implementation
                pass
            elif db_type == 'postgresql':
                # PostgreSQL implementation
                pass
            else:
                self.logger.warning(f"Noma'lum ma'lumotlar bazasi turi: {db_type}")
                
        except Exception as e:
            self.logger.error(f"Ma'lumotlar bazasiga saqlashda xatolik: {str(e)}")

    def expose_prometheus_metrics(self, metrics):
        """Expose metrics for Prometheus if enabled."""
        if not self.config['prometheus_enabled']:
            return
        
        try:
            # This is a placeholder for Prometheus integration
            # In a real implementation, you would expose these metrics via HTTP endpoint
            self.logger.debug(f"Prometheus uchun metrikalar tayyorlandi: {metrics}")
            
            # Example implementation would use a library like prometheus_client
            # to expose these metrics via HTTP endpoint
            
        except Exception as e:
            self.logger.error(f"Prometheus metrikalarini tayyorlashda xatolik: {str(e)}")

    def update_status_file(self, metrics):
        """Update status file with current metrics."""
        status_file = "/tmp/memory-monitor-status.tmp"
        date_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        try:
            with open(status_file, 'w') as f:
                f.write(f"So'nggi tekshirish: {date_str}\n")
                
                for key, value in metrics.items():
                    if key == 'ram':
                        f.write(f"RAM: {value}%\n")
                    elif key == 'cpu' and self.config['monitor_cpu']:
                        f.write(f"CPU: {value}%\n")
                    elif key == 'disk' and self.config['monitor_disk']:
                        f.write(f"Disk ({self.config['disk_path']}): {value}%\n")
                    elif key == 'swap' and self.config['monitor_swap'] and value > 0:
                        f.write(f"Swap: {value}%\n")
                    elif key == 'load' and self.config['monitor_load']:
                        load_per_core = value / 100  # Convert back from percentage
                        load_1min = load_per_core * psutil.cpu_count(logical=True)
                        f.write(f"Load: {load_1min:.2f} (core boshiga: {load_per_core:.2f})\n")
                    elif key == 'network' and self.config['monitor_network']:
                        rx_rate, tx_rate = value
                        f.write(f"Network ({self.config['network_interface']}): RX: {rx_rate:.2f} Mbps, TX: {tx_rate:.2f} Mbps\n")
        
        except Exception as e:
            self.logger.error(f"Status faylini yangilashda xatolik: {str(e)}")

    def run(self):
        """Run the monitoring loop."""
        self.logger.info(f"Monitoring boshlandi. Interval: {self.config['check_interval']} soniya")
        
        while True:
            try:
                # Collect all metrics
                metrics = {
                    'ram': self.check_ram_usage(),
                    'cpu': self.check_cpu_usage(),
                    'disk': self.check_disk_usage(),
                    'swap': self.check_swap_usage(),
                    'load': self.check_load_average(),
                    'network': self.check_network_usage()
                }
                
                # Store metrics in database if enabled
                self.store_metrics_in_database(metrics)
                
                # Expose metrics for Prometheus if enabled
                self.expose_prometheus_metrics(metrics)
                
                # Update status file
                self.update_status_file(metrics)
                
                # Check thresholds and send alerts
                
                # RAM check
                if metrics['ram'] >= self.config['threshold']:
                    self.logger.warning(f"Yuqori RAM ishlatilishi: {metrics['ram']}%")
                    self.send_telegram_alert("RAM", f"{metrics['ram']}%")
                
                # CPU check
                if self.config['monitor_cpu'] and metrics['cpu'] >= self.config['cpu_threshold']:
                    self.logger.warning(f"Yuqori CPU ishlatilishi: {metrics['cpu']}%")
                    self.send_telegram_alert("CPU", f"{metrics['cpu']}%")
                
                # Disk check
                if self.config['monitor_disk'] and metrics['disk'] >= self.config['disk_threshold']:
                    self.logger.warning(f"Yuqori disk ishlatilishi ({self.config['disk_path']}): {metrics['disk']}%")
                    self.send_telegram_alert("Disk", f"{metrics['disk']}%")
                
                # Swap check
                if self.config['monitor_swap'] and metrics['swap'] >= self.config['swap_threshold'] and metrics['swap'] > 0:
                    self.logger.warning(f"Yuqori swap ishlatilishi: {metrics['swap']}%")
                    self.send_telegram_alert("Swap", f"{metrics['swap']}%")
                
                # Load check
                if self.config['monitor_load'] and metrics['load'] >= self.config['load_threshold']:
                    load_per_core = metrics['load'] / 100  # Convert back from percentage
                    load_1min = load_per_core * psutil.cpu_count(logical=True)
                    self.logger.warning(f"Yuqori load average: {load_1min:.2f} (core boshiga: {load_per_core:.2f})")
                    self.send_telegram_alert("Load", f"{load_1min:.2f} (core boshiga: {load_per_core:.2f})")
                
                # Network check
                if self.config['monitor_network']:
                    rx_rate, tx_rate = metrics['network']
                    if rx_rate >= self.config['network_threshold'] or tx_rate >= self.config['network_threshold']:
                        self.logger.warning(f"Yuqori network trafigi ({self.config['network_interface']}): RX: {rx_rate:.2f} Mbps, TX: {tx_rate:.2f} Mbps")
                        self.send_telegram_alert("Network", f"RX: {rx_rate:.2f} Mbps, TX: {tx_rate:.2f} Mbps")
                
            except Exception as e:
                self.logger.error(f"Monitoring jarayonida xatolik: {str(e)}")
            
            # Wait for next check
            time.sleep(self.config['check_interval'])


def main():
    """Main function to parse arguments and start monitoring."""
    parser = argparse.ArgumentParser(description='System Resource Monitoring Tool')
    parser.add_argument('--config', dest='config_file', default=DEFAULT_CONFIG_FILE,
                        help=f'Path to configuration file (default: {DEFAULT_CONFIG_FILE})')
    parser.add_argument('--version', action='version', version='System Monitor 1.0.0')
    
    args = parser.parse_args()
    
    # Start monitoring
    monitor = SystemMonitor(config_file=args.config_file)
    monitor.run()


if __name__ == "__main__":
    main()
