# System Monitor - Python Version

## Overview

System Monitor is a comprehensive monitoring tool that tracks system resources (RAM, CPU, disk, swap, load, network) and sends alerts via Telegram when thresholds are exceeded. This Python version offers enhanced capabilities including database integration for metrics storage and Prometheus/Grafana integration for visualization.

## Features

- **Resource Monitoring**:
  - RAM usage monitoring
  - CPU usage monitoring
  - Disk usage monitoring
  - Swap usage monitoring
  - System load monitoring
  - Network traffic monitoring

- **Alerting**:
  - Telegram notifications with detailed system information
  - Configurable thresholds for each resource
  - Rate limiting to prevent alert flooding
  - Retry mechanism for reliable delivery

- **Database Integration**:
  - Support for SQLite, MySQL, and PostgreSQL
  - Storage of metrics and alerts
  - Historical data querying
  - Statistical summaries

- **Prometheus/Grafana Integration**:
  - Metrics exposure for Prometheus scraping
  - Ready-to-use Grafana dashboard
  - Alert counters
  - System information

## Requirements

- Python 3.6 or higher
- Required Python packages:
  - `psutil` - For system metrics collection
  - `requests` - For Telegram API communication
  - For database support (optional):
    - SQLite: Built-in
    - MySQL: `mysql-connector-python`
    - PostgreSQL: `psycopg2-binary`
  - For Prometheus integration (optional):
    - `prometheus_client`

## Installation

1. Clone the repository or download the files
2. Install required packages:

```bash
pip install psutil requests

# For MySQL support
pip install mysql-connector-python

# For PostgreSQL support
pip install psycopg2-binary

# For Prometheus integration
pip install prometheus_client
```

3. Create configuration file (see Configuration section)
4. Run the script:

```bash
python memory_monitor.py --config /path/to/config.conf
```

## Configuration

The script uses a configuration file in INI format. Here's a sample configuration:

```ini
[General]
bot_token = YOUR_TELEGRAM_BOT_TOKEN
chat_id = YOUR_TELEGRAM_CHAT_ID
log_file = /var/log/memory_monitor.log
log_level = INFO
threshold = 80
check_interval = 60
alert_message_title = 🛑 SYSTEM MONITOR ALERT
include_top_processes = true
top_processes_count = 10

[CPU]
monitor_cpu = true
cpu_threshold = 90

[Disk]
monitor_disk = true
disk_threshold = 90
disk_path = /

[Swap]
monitor_swap = true
swap_threshold = 80

[Load]
monitor_load = true
load_threshold = 5

[Network]
monitor_network = true
network_interface = eth0
network_threshold = 90

[Database]
db_enabled = false
db_type = sqlite
db_path = /var/lib/memory-monitor/metrics.db
# For MySQL/PostgreSQL
db_host = localhost
db_port = 3306
db_name = system_monitor
db_user = username
db_password = password

[Prometheus]
prometheus_enabled = false
prometheus_port = 9090
```

## Database Integration

The system supports three database types:

### SQLite

Simplest option, stores data in a local file. Good for single-server deployments.

```ini
[Database]
db_enabled = true
db_type = sqlite
db_path = /var/lib/memory-monitor/metrics.db
```

### MySQL

Good for centralized monitoring of multiple servers.

```ini
[Database]
db_enabled = true
db_type = mysql
db_host = localhost
db_port = 3306
db_name = system_monitor
db_user = username
db_password = password
```

### PostgreSQL

Advanced option with better performance for large datasets.

```ini
[Database]
db_enabled = true
db_type = postgresql
db_host = localhost
db_port = 5432
db_name = system_monitor
db_user = username
db_password = password
```

## Prometheus/Grafana Integration

### Enabling Prometheus Integration

```ini
[Prometheus]
prometheus_enabled = true
prometheus_port = 9090
```

### Setting Up Grafana

1. Add Prometheus as a data source in Grafana
2. Import the provided dashboard JSON
3. Customize as needed

## Running as a Service

To run the script as a systemd service:

1. Create a service file:

```bash
sudo nano /etc/systemd/system/memory-monitor.service
```

2. Add the following content:

```
[Unit]
Description=System Memory, CPU and Disk Monitoring Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /path/to/memory_monitor.py --config /etc/memory-monitor/config.conf
Restart=always
RestartSec=10
User=root
Group=root

[Install]
WantedBy=multi-user.target
```

3. Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable memory-monitor.service
sudo systemctl start memory-monitor.service
```

## Troubleshooting

### Telegram Notifications Not Working

1. Verify your bot token and chat ID
2. Check if the bot has been added to the chat
3. Ensure the bot has permission to send messages
4. Check the log file for detailed error messages

### Database Connection Issues

1. Verify database credentials
2. Ensure the database server is running
3. Check if the required Python packages are installed
4. Verify network connectivity to the database server

### Prometheus Integration Issues

1. Ensure prometheus_client package is installed
2. Check if the port is available and not blocked by firewall
3. Verify Prometheus is configured to scrape the metrics endpoint

## Advanced Usage

### Custom Metrics Collection

You can extend the system to collect additional metrics by modifying the main script. Add new methods to collect metrics and update the monitoring loop.

### Integration with Other Notification Systems

The system can be extended to support other notification systems like email, Slack, or webhook notifications by adding new notification handlers.

### Multi-Server Monitoring

For monitoring multiple servers:

1. Install the script on each server
2. Configure a central database (MySQL or PostgreSQL)
3. Point all instances to the same database
4. Use Grafana for visualization

## Database Schema

The system uses two main tables:

### Metrics Table

Stores regular metrics collected from the system.

```sql
CREATE TABLE metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME NOT NULL,
    hostname TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    ram_usage REAL,
    cpu_usage REAL,
    disk_usage REAL,
    swap_usage REAL,
    load_average REAL,
    network_rx REAL,
    network_tx REAL,
    extra_data TEXT
);
```

### Alerts Table

Stores information about alerts that were triggered.

```sql
CREATE TABLE alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME NOT NULL,
    hostname TEXT NOT NULL,
    alert_type TEXT NOT NULL,
    value TEXT NOT NULL,
    message TEXT,
    sent_successfully BOOLEAN
);
```

## Prometheus Metrics

The following metrics are exposed for Prometheus:

- `system_monitor_info` - System information
- `system_monitor_ram_usage_percent` - RAM usage in percent
- `system_monitor_cpu_usage_percent` - CPU usage in percent
- `system_monitor_disk_usage_percent` - Disk usage in percent
- `system_monitor_swap_usage_percent` - Swap usage in percent
- `system_monitor_load_average` - System load average
- `system_monitor_network_rx_mbps` - Network receive rate in Mbps
- `system_monitor_network_tx_mbps` - Network transmit rate in Mbps
- `system_monitor_ram_alerts_total` - Total number of RAM alerts
- `system_monitor_cpu_alerts_total` - Total number of CPU alerts
- `system_monitor_disk_alerts_total` - Total number of disk alerts
- `system_monitor_swap_alerts_total` - Total number of swap alerts
- `system_monitor_load_alerts_total` - Total number of load alerts
- `system_monitor_network_alerts_total` - Total number of network alerts

## Security Considerations

- **Database Credentials**: Store database credentials securely and limit database user permissions
- **Telegram Bot Token**: Keep your bot token confidential
- **Prometheus Endpoint**: Consider adding authentication if exposed publicly
- **Log Files**: Ensure log files don't contain sensitive information
- **Running as Root**: Consider running the service as a non-root user with appropriate permissions

## Performance Considerations

- **Check Interval**: Adjust the check interval based on your needs and server performance
- **Database Storage**: For long-term storage, consider database maintenance (indexing, partitioning)
- **Top Processes**: Collecting top processes can be resource-intensive; adjust or disable if needed
- **Prometheus Metrics**: High scrape frequency can impact performance

## Future Enhancements

- Web interface for configuration and monitoring
- Support for additional notification channels (email, Slack, webhooks)
- More detailed process monitoring
- Custom plugin support for additional metrics
- Anomaly detection using historical data
- API for integration with other systems
